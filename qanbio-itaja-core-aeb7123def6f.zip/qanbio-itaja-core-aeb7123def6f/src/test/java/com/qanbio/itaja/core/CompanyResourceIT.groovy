package com.qanbio.itaja.core

import com.qanbio.itaja.core.domain.Employee
import com.qanbio.itaja.core.domain.Product
import com.qanbio.itaja.core.domain.Sale
import com.qanbio.itaja.core.domain.Shop
import io.restassured.RestAssured
import io.restassured.http.ContentType
import org.testng.annotations.BeforeClass
import org.testng.annotations.Test

import java.time.Instant

import static io.restassured.RestAssured.given
import static org.assertj.core.api.Assertions.assertThat

//GET /companies/{companyId}/products
//GET /companies/{companyId}/shops
//GET /companies/{companyId}/shops/{shopReference}/expenditures
//PATCH /companies/{companyId}/shops/{shopReference}/expenditures
//GET /companies/{companyId}/shops/{shopReference}/inventories
//PATCH /companies/{companyId}/shops/{shopReference}/inventories
//GET /companies/{companyId}/shops/{shopReference}/procurements
//PATCH /companies/{companyId}/shops/{shopReference}/procurements
//GET /companies/{companyId}/shops/{shopReference}/sales
//PATCH /companies/{companyId}/shops/{shopReference}/sales

class CompanyResourceIT {
    @BeforeClass
    void init() {
        RestAssured.baseURI = 'http://localhost'
        RestAssured.port = 9010
    }

    @Test
    void should_return_at_leat_shop_vedoko_of_company_1010001073() {
        Long companyId = 1010001073

        List<Shop> shops = given()
                .pathParam('companyId', companyId)
                .when().get('/v1/companies/{companyId}/shops')
                .then()
                .extract().as(Shop[].class) as List<Shop>

        assertThat(shops).isNotEmpty()
        assertThat(shops.find { it.reference == 'vedoko' })
    }

    @Test
    void should_return_all_products_of_company_1010001073() {
        Long companyId = 1010001073

        List<Product> products = given()
                .pathParam('companyId', companyId)
                .when().get('/v1/companies/{companyId}/products')
                .then()
                .extract().as(Product[].class) as List<Product>

        assertThat(products).isNotEmpty()
        assertThat(products.find { it.reference == '161110-1-F-RBE-0018' })
    }

    @Test
    void should_save_a_sale_related_to_company_1010001073() {
        Long companyId = 1010001073
        String shopReference = 'vedoko'
        List<Sale> salesToSave = [
                new Sale(
                        operationDate: Instant.now(),
                        unitAmount: 1200,
                        quantity: 10,
                        totalAmount: 12000,
                        note: 'first sale today !!!',
                        shop: new Shop(reference: 'vedoko'),
                        product: new Product(reference: '161110-1-F-RBE-0043'),
                        employee: new Employee(phoneNumber: '+22966127191')
                )]

        List<Sale> sales = given()
                .pathParam('companyId', companyId)
                .pathParam('shopReference', shopReference)
                .accept(ContentType.JSON.withCharset('UTF-8'))
                .body(salesToSave)
                .when().patch('/v1/companies/{companyId}/shops/{shopReference}/sales')
                .then()
                .extract().as(Sale[].class) as List<Sale>

        assertThat(sales.find { it.product.reference == '161110-1-F-RBE-0043' })
    }
}