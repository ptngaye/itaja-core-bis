package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Expenditure
import com.qanbio.itaja.core.domain.Shop
import com.qanbio.itaja.core.repositories.CompanyRepository
import com.qanbio.itaja.core.repositories.ExpenditureRepository
import com.qanbio.itaja.core.repositories.ShopRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import java.time.Instant

@Service
class ExpenditureService {
    ExpenditureRepository expenditureRepository
    CompanyRepository companyRepository
    ShopRepository shopRepository

    List<Expenditure> findAll() {
        expenditureRepository.findAll()
    }

    List<Expenditure> findByShopId(Long shopId) {
        expenditureRepository.findByShop_Id(shopId)
    }

    List<Expenditure> findByShopReferenceAndByCompanyId(Long companyId, String shopReference) {
        List<Shop> shops = shopRepository.findByCompany_Id(companyId)
        Shop shop = shops.find { Shop shop -> shop.reference == shopReference }
        expenditureRepository.findByShop_Id(shop.id)
    }

    List<Expenditure> findByCompanyId(Long companyId) {
        List<Shop> shops = shopRepository.findByCompany_Id(companyId)
        shops.collectMany{Shop shop -> expenditureRepository.findByShop_Id(shop.id)}
    }

    Expenditure findOneById(Long expenditureId) {
        expenditureRepository.findOne(expenditureId)
    }

    List<Expenditure> createOrUpdate(Long companyId, String shopReference, List<Expenditure> expenditures) {
        Shop shop = companyRepository.findOne(companyId).shops.find { Shop shop -> shop.reference == shopReference }

        Instant now = Instant.now()

        expenditures.each { Expenditure expenditure ->
            expenditure.createdAt = now
            expenditure.shop = shop
        }
        expenditureRepository.save(expenditures)
    }

    @Autowired
    void setExpenditureRepository(ExpenditureRepository expenditureRepository) {
        this.expenditureRepository = expenditureRepository
    }

    @Autowired
    void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository
    }

    @Autowired
    void setShopRepository(ShopRepository shopRepository) {
        this.shopRepository = shopRepository
    }
}
