package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Shop
import org.springframework.data.jpa.repository.JpaRepository

interface ShopRepository extends JpaRepository<Shop, Long> {
    List<Shop> findByCompany_Id(Long companyId)
}
