package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Inventory
import org.springframework.data.jpa.repository.JpaRepository

interface InventoryRepository extends JpaRepository<Inventory, Long> {
    List<Inventory> findByShop_Id(Long shopId)
}
