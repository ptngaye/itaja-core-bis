package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder

import javax.persistence.*
import javax.validation.constraints.NotNull
import java.time.Instant

@Entity
@Table(name = "inventories")
@JsonPropertyOrder(alphabetic = true)
class Inventory {
    @JsonProperty("id")
    @Column(name = "inventory_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @JsonProperty("createdAt")
    @Column(name = "created_at")
    Instant createdAt

    @JsonProperty("operationDate")
    @Column(name = "operation_date")
    Instant operationDate

    @JsonProperty("quantity")
    @Column(name = "quantity")
    BigDecimal quantity

    @JsonProperty("note")
    @Column(name = "note")
    String note

    @NotNull(message = "{Inventory.product.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    Product product

    @NotNull(message = "{Inventory.shop.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "shop_id")
    Shop shop

    @NotNull(message = "{Inventory.employee.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_id")
    Employee employee

}
