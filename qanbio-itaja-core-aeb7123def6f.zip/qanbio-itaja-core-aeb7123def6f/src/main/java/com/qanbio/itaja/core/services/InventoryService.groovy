package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Employee
import com.qanbio.itaja.core.domain.Inventory
import com.qanbio.itaja.core.domain.Product
import com.qanbio.itaja.core.domain.Shop
import com.qanbio.itaja.core.repositories.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import java.time.Instant

@Service
class InventoryService {
    InventoryRepository inventoryRepository
    CompanyRepository companyRepository
    ShopRepository shopRepository
    ProductRepository productRepository
    EmployeeRepository employeeRepository

    List<Inventory> findAll() {
        inventoryRepository.findAll()
    }

    List<Inventory> findByShopId(Long shopId) {
        inventoryRepository.findByShop_Id(shopId)
    }

    List<Inventory> findByShopReferenceAndByCompanyId(Long companyId, String shopReference) {
        List<Shop> shops = shopRepository.findByCompany_Id(companyId)
        Shop shop = shops.find { Shop shop -> shop.reference == shopReference }
        inventoryRepository.findByShop_Id(shop.id)
    }

    Inventory findOneById(Long inventoryId) {
        inventoryRepository.findOne(inventoryId)
    }

    List<Inventory> createOrUpdate(Long companyId, String shopReference, List<Inventory> inventories) {
        Shop shop = companyRepository.findOne(companyId).shops.find { Shop shop -> shop.reference == shopReference }
        List<Product> products = productRepository.findByCompany_Id(companyId)
        List<Employee> employees = employeeRepository.findByCompany_Id(companyId)

        Instant now = Instant.now()

        inventories.each { Inventory inventory ->
            inventory.createdAt = now
            inventory.shop = shop
            inventory.product = products.find { it.reference == inventory.product.reference }
            inventory.employee = employees.find { it.phoneNumber == inventory.employee.phoneNumber }
        }

        inventoryRepository.save(inventories)
    }

    @Autowired
    void setInventoryRepository(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository
    }

    @Autowired
    void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository
    }

    @Autowired
    void setShopRepository(ShopRepository shopRepository) {
        this.shopRepository = shopRepository
    }

    @Autowired
    void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository
    }

    @Autowired
    void setEmployeeRepository(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository
    }
}
