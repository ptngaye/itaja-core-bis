package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Employee
import org.springframework.data.jpa.repository.JpaRepository

interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByCompany_Id(Long companyId)
}
