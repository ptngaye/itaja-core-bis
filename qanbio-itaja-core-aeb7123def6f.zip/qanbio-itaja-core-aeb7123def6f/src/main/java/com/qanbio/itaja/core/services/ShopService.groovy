package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Shop
import com.qanbio.itaja.core.repositories.ShopRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ShopService {
    ShopRepository shopRepository

    List<Shop> findAll() {
        shopRepository.findAll()
    }

    List<Shop> findByCompanyId(Long companyId) {
        shopRepository.findByCompany_Id(companyId)
    }

    Shop findOneById(Long shopId) {
        shopRepository.findOne(shopId)
    }

    @Autowired
    void setShopRepository(ShopRepository shopRepository) {
        this.shopRepository = shopRepository
    }
}