package com.qanbio.itaja.core

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import springfox.documentation.builders.PathSelectors
import springfox.documentation.builders.RequestHandlerSelectors
import springfox.documentation.service.ApiInfo
import springfox.documentation.service.Contact
import springfox.documentation.spi.DocumentationType
import springfox.documentation.spring.web.plugins.Docket
import springfox.documentation.swagger2.annotations.EnableSwagger2

@Configuration
@EnableSwagger2
class SwaggerConfig {
    @Bean
    Docket api() {
        new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.qanbio.itaja.core.controllers"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo())
//                .produces('application/json')
//                .consumes('application/json')
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact(
                'QANBIO',
                'qanbio.com',
                'contact@qanbio.com')

        new ApiInfo(
                'ITAJA',
                'ITAJA Backend services',
                'v1',
                'Only for QANBIO custumers',
                contact,
                '',
                ''
        )
    }
}
//.apiInfo(apiInfo)
//        .selector(apiSelector)
//        .applyDefaultResponseMessages(applyDefaultResponseMessages)
//        .additionalResponseMessages(responseMessages)
//        .additionalOperationParameters(globalOperationParameters)
//        .additionalIgnorableTypes(ignorableParameterTypes)
//        .ruleBuilders(ruleBuilders)
//        .groupName(groupName)
//        .pathProvider(pathProvider)
//        .securityContexts(securityContexts)
//        .securitySchemes(securitySchemes)
//        .apiListingReferenceOrdering(apiListingReferenceOrdering)
//        .apiDescriptionOrdering(apiDescriptionOrdering)
//        .operationOrdering(operationOrdering)
//        .produces(produces)
//        .consumes(consumes)
//        .host(host)
//        .protocols(protocols)
//        .genericsNaming(genericsNamingStrategy)
//        .pathMapping(pathMapping)
//        .enableUrlTemplating(enableUrlTemplating)
//        .additionalModels(additionalModels)
//        .tags(tags)
//        .build();
