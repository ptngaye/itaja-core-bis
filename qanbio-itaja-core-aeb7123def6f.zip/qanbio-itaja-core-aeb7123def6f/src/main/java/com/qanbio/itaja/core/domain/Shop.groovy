package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.hibernate.validator.constraints.Email
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*
import javax.validation.constraints.NotNull

@Entity
@Table(name = "shops")
@JsonPropertyOrder(alphabetic = true)
class Shop {
    @JsonProperty("id")
    @Column(name = "shop_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @NotBlank(message = "{Shop.reference.NotBlank}")
    @JsonProperty("reference")
    @Column(name = "reference")
    String reference

    @NotBlank(message = "{Shop.name.NotBlank}")
    @JsonProperty("name")
    @Column(name = "name")
    String name

    @Email(message = "{Shop.emailAdress.Email}")
    @JsonProperty("emailAddress")
    @Column(name = "email_address")
    String emailAddress

    @NotBlank(message = "{Shop.phoneNumber.NotBlank}")
    @JsonProperty("phoneNumber")
    @Column(name = "phone_number")
    String phoneNumber

    @NotNull(message = "{Shop.company.NotBlank}")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id")
    @JsonBackReference
    Company company
}