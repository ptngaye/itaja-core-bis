package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Employee
import com.qanbio.itaja.core.repositories.EmployeeRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class EmployeeService {
    EmployeeRepository employeeRepository

    List<Employee> findAll() {
        employeeRepository.findAll()
    }

    List<Employee> findByCompanyId(Long companyId) {
        employeeRepository.findByCompany_Id(companyId)
    }

    Employee findOneById(Long employeeId) {
        employeeRepository.findOne(employeeId)
    }

    @Autowired
    void setEmployeeRepository(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository
    }
}


