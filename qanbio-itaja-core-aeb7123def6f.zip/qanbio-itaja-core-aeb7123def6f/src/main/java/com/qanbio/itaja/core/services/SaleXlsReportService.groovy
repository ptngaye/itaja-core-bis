package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Sale
import org.apache.poi.hssf.usermodel.HSSFDataFormat
import org.apache.poi.hssf.usermodel.HSSFPalette
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.hssf.util.HSSFColor
import org.apache.poi.ss.usermodel.*
import org.apache.poi.ss.util.CellRangeAddress
import org.springframework.stereotype.Service

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.Instant

@Service
class SaleXlsReportService {
    Workbook buildReport(List<Sale> sales) {
        HSSFWorkbook workbook = new HSSFWorkbook()

        Sheet sheet = workbook.createSheet()

        buildSheet(sheet, sales.size() + 2000, 75)

        mergeCells(sheet)

        sizeCells(sheet)

        sheet.getRow(6).setHeight((short) 500)

        buildReportHeader(sheet)

        buildSalesTable(sheet, sales)

        workbook.setSheetName(0, 'JOURNAL-DE-VENTE')

        workbook
    }

    private void buildReportHeader(Sheet sheet) {
        Cell reportNameCell = sheet.getRow(1).getCell(1)
        Cell buildByCell = sheet.getRow(2).getCell(1)
        Cell periodCell = sheet.getRow(3).getCell(1)
        Cell companyNameCell = sheet.getRow(1).getCell(5)
        Cell totalAmountCell = sheet.getRow(3).getCell(5)

        reportNameCell.with {
            cellValue = 'Journal des ventes'
            cellStyle = buildReportNameCellStyle((HSSFWorkbook) sheet.getWorkbook())
        }
        buildByCell.with {
            cellValue = 'Built with ITAJA'
            cellStyle = buildBuildByCellStyle((HSSFWorkbook) sheet.getWorkbook())
        }
        periodCell.with {
            cellValue = 'Du 22/02/2017 au 01/03/2017'
            cellStyle = buildPeriodCellStyle((HSSFWorkbook) sheet.getWorkbook())
        }
        companyNameCell.with {
            cellValue = 'Shek Shop'
            cellStyle = buildCompanyNameCellStyle((HSSFWorkbook) sheet.getWorkbook())
        }
        totalAmountCell.with {
            cellValue = 'Total des ventes : 450 000 XOF'
            cellStyle = buildTotalAmountCellStyle((HSSFWorkbook) sheet.getWorkbook())
        }
    }

    private void buildSalesTable(Sheet sheet, List<Sale> sales) {
        buildSalesTableHeader(sheet)
        buildSalesTableInternal(sheet, sales)
    }

    private void buildSalesTableHeader(Sheet sheet) {
        CellStyle headerCellStyle = buildHeaderCellStyle((HSSFWorkbook) sheet.getWorkbook())

        Row row = sheet.getRow(6)
        Cell columnOperationDate = row.getCell(1)
        Cell columnReference = row.getCell(2)
        Cell columnQuantity = row.getCell(3)
        Cell columnUnitAmount = row.getCell(4)
        Cell columnTotalAmount = row.getCell(5)
        Cell columnNote = row.getCell(6)

        columnOperationDate.with {
            cellValue = 'DATE'
            cellStyle = headerCellStyle
        }
        columnReference.with {
            cellValue = 'PRODUIT'
            cellStyle = headerCellStyle
        }
        columnQuantity.with {
            cellValue = 'QTE'
            cellStyle = headerCellStyle
        }
        columnUnitAmount.with {
            cellValue = 'PU'
            cellStyle = headerCellStyle
        }
        columnTotalAmount.with {
            cellValue = 'TOTAL'
            cellStyle = headerCellStyle
        }
        columnNote.with {
            cellValue = 'REMARQUE'
            cellStyle = headerCellStyle
        }
    }

    private void buildSalesTableInternal(Sheet sheet, List<Sale> sales) {
        CellStyle dataCellStyle = buildDataCellStyle((HSSFWorkbook) sheet.getWorkbook())

        sales.eachWithIndex { Sale sale, int index ->
            Row row = sheet.getRow(index + 7)
            Cell columnOperationDate = row.getCell(1)
            Cell columnReference = row.getCell(2)
            Cell columnQuantity = row.getCell(3)
            Cell columnUnitAmount = row.getCell(4)
            Cell columnTotalAmount = row.getCell(5)
            Cell columnNote = row.getCell(6)

            columnOperationDate.with {
                cellValue = format(sale.operationDate)
                cellStyle = dataCellStyle
            }

            columnReference.with {
                cellValue = String.valueOf(sale.product.reference)
                cellStyle = dataCellStyle
            }

            columnQuantity.with {
                cellValue = String.valueOf(sale.quantity)
                cellStyle = dataCellStyle
            }
            columnUnitAmount.with {
                cellValue = String.valueOf(sale.unitAmount)
                cellStyle = dataCellStyle
            }
            columnTotalAmount.with {
                cellValue = String.valueOf(sale.totalAmount)
                cellStyle = dataCellStyle
            }

            columnNote.with {
                cellValue = sale.note
                cellStyle = dataCellStyle
            }
        }
    }

    private CellStyle buildDefaultCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = workbook.createCellStyle()
        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"))
        cellStyle.setFont(buildDataFont(workbook))

        cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle
    }

    private CellStyle buildReportNameCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = workbook.createCellStyle()
        cellStyle.setAlignment(HorizontalAlignment.LEFT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"))
        cellStyle.setFont(buildReportNameFont(workbook))

        cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle
    }

    private CellStyle buildCompanyNameCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = workbook.createCellStyle()
        cellStyle.setAlignment(HorizontalAlignment.RIGHT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"))
        cellStyle.setFont(buildCompanyNameFont(workbook))

        cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle
    }

    private CellStyle buildTotalAmountCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = workbook.createCellStyle()
        cellStyle.setAlignment(HorizontalAlignment.RIGHT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"))
        cellStyle.setFont(buildTotalAmountFont(workbook))

        cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle
    }

    private CellStyle buildDataCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = buildDefaultCellStyle(workbook)
        cellStyle.setAlignment(HorizontalAlignment.RIGHT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setBorderBottom(BorderStyle.THIN)
        cellStyle.setBorderTop(BorderStyle.THIN)
        cellStyle.setBorderRight(BorderStyle.THIN)
        cellStyle.setBorderLeft(BorderStyle.THIN)
        cellStyle.setFont(buildDataFont(workbook))

        cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle
    }

    private CellStyle buildHeaderCellStyle(HSSFWorkbook workbook) {
        HSSFPalette palette = workbook.getCustomPalette()
        HSSFColor colorItajaBlue = palette.findSimilarColor(65, 74, 117)
        short colorItajaBlueSimilar = colorItajaBlue.getIndex()

        CellStyle cellStyle = buildDefaultCellStyle(workbook)
        cellStyle.setAlignment(HorizontalAlignment.CENTER)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setFillForegroundColor(colorItajaBlueSimilar)// cellStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex())
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)

        cellStyle.setBorderBottom(BorderStyle.THIN)
        cellStyle.setBorderTop(BorderStyle.THIN)
        cellStyle.setBorderRight(BorderStyle.THIN)
        cellStyle.setBorderLeft(BorderStyle.THIN)
        cellStyle.setFont(buildHeaderFont(workbook))
        cellStyle
    }

    private CellStyle buildBuildByCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = buildDefaultCellStyle(workbook)
        cellStyle.setAlignment(HorizontalAlignment.LEFT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setFont(buildBuildByFont(workbook))
        cellStyle
    }

    private CellStyle buildPeriodCellStyle(HSSFWorkbook workbook) {
        CellStyle cellStyle = buildDefaultCellStyle(workbook)
        cellStyle.setAlignment(HorizontalAlignment.LEFT)
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER)

        cellStyle.setFont(buildPeriodFont(workbook))
        cellStyle
    }

    private Font buildReportNameFont(HSSFWorkbook workbook) {

        HSSFPalette palette = workbook.getCustomPalette()
        HSSFColor colorItajaGreen = palette.findSimilarColor(56, 180, 73)
        short colorItajaGreenSimilar = colorItajaGreen.getIndex()


        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 800)
        font.setColor(colorItajaGreenSimilar)//font.setColor(HSSFColor.HSSFColorPredefined.BRIGHT_GREEN.index)
        font.setFontHeight((short) 800)
        font.setBold(true)
        font
    }

    private Font buildCompanyNameFont(Workbook workbook) {
        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 700)
        font.setColor(HSSFColor.HSSFColorPredefined.GREY_50_PERCENT.index)
        font.setFontHeight((short) 700)
        font.setBold(true)
        font
    }

    private Font buildTotalAmountFont(Workbook workbook) {
        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 400)
        font.setColor(HSSFColor.HSSFColorPredefined.GREY_50_PERCENT.index)
        font.setFontHeight((short) 400)
        font.setBold(true)
        font
    }

    private Font buildBuildByFont(Workbook workbook) {
        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 150)
        font.setColor(HSSFColor.HSSFColorPredefined.GREY_50_PERCENT.index)
        font.setFontHeight((short) 150)
        font.setBold(true)
        font.setItalic(true)
        font
    }

    private Font buildPeriodFont(Workbook workbook) {
        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 400)
        font.setColor(HSSFColor.HSSFColorPredefined.GREY_50_PERCENT.index)
        font.setFontHeight((short) 400)
        font.setBold(true)
        font.setItalic(false)
        font
    }

    private Font buildDataFont(HSSFWorkbook workbook) {
        HSSFPalette palette = workbook.getCustomPalette()
        HSSFColor colorItajaBlue = palette.findSimilarColor(65, 74, 117)
        short colorItajaBlueSimilar = colorItajaBlue.getIndex()

        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 200)
        font.setColor(colorItajaBlueSimilar)//HSSFColor.HSSFColorPredefined.BLUE.index
        font.setFontHeight((short) 200)
        font
    }

    private Font buildHeaderFont(HSSFWorkbook workbook) {
        Font font = workbook.createFont()
        font.setFontName('Calibri')
        font.setFontHeightInPoints((short) 200)
        font.setColor(HSSFColor.HSSFColorPredefined.WHITE.index)
        font.setFontHeight((short) 200)
        font.setBold(true)
        font
    }

    private void buildSheet(Sheet sheet, int nbRows, int nbColumns) {
        CellStyle defaultCellStyle = buildDefaultCellStyle((HSSFWorkbook) sheet.getWorkbook())

        for (short rowIndex = 0; rowIndex < nbRows; rowIndex++) {
            Row row = sheet.createRow(rowIndex)
            for (short columnIndex = 0; columnIndex < nbColumns; columnIndex++) {
                Cell cell = row.createCell(columnIndex)
                cell.cellStyle = defaultCellStyle
            }
        }
    }

    private void mergeReportNameCells(Sheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(
                1, 1, 1, 4
        ))
    }

    private void mergeCompanyNameCells(Sheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(
                1, 1, 5, 6
        ))
    }

    private void mergeTotalCells(Sheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(
                3, 3, 5, 6
        ))
        sheet.addMergedRegion(new CellRangeAddress(
                2, 2, 5, 6
        ))
    }

    private void mergeBuildByCells(Sheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(
                2, 2, 1, 4
        ))
    }

    private void mergePeriodCells(Sheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(
                3, 3, 1, 4
        ))
    }

    private void defineColumnWidth(Sheet sheet) {
        sheet.setColumnWidth(1, 3000)//DATE
        sheet.setColumnWidth(2, 6000)//PRODUIT
        sheet.setColumnWidth(3, 2500)//QTE
        sheet.setColumnWidth(4, 2500)//PV UNITAIRE
        sheet.setColumnWidth(5, 2500)//PV TOTAL
        sheet.setColumnWidth(6, 24000)//REMARQUE
    }

    private void defineRowHeight(Sheet sheet) {
        def defineRowSize = { int rowNum ->
            sheet.getRow(rowNum).setHeight((short) 350)
        }
        7.upto(sheet.getLastRowNum(), defineRowSize)
    }

    private void mergeCells(Sheet sheet) {
        mergeBuildByCells(sheet)
        mergeCompanyNameCells(sheet)
        mergePeriodCells(sheet)
        mergeReportNameCells(sheet)
        mergeTotalCells(sheet)
    }

    private void sizeCells(Sheet sheet) {
        defineColumnWidth(sheet)
        defineRowHeight(sheet)
    }

    private boolean isColDate(Cell cell) {
        (cell.rowIndex > 6 && cell.columnIndex == 1)
    }

    private boolean isColProduct(Cell cell) {
        (cell.rowIndex > 6 && cell.columnIndex == 2)
    }

    private boolean isColQuantity(Cell cell) {
        int rowIndex = cell.getRowIndex()
        int columnIndex = cell.getColumnIndex()
        (cell.rowIndex > 6 && cell.columnIndex == 3)
    }

    private boolean isColUnitAmount(Cell cell) {
        (cell.rowIndex > 6 && cell.columnIndex == 4)
    }

    private boolean isColTotalAmount(Cell cell) {
        (cell.rowIndex > 6 && cell.columnIndex == 5)
    }

    private boolean isColRemark(Cell cell) {
        (cell.rowIndex > 6 && cell.columnIndex == 6)
    }

    private String format(Instant instant) {
        DateFormat format = new SimpleDateFormat('dd/MM/yyyy')
        Date date = new Date(instant.toEpochMilli())
        format.format(date)
    }

//    static void main(String[] args) {
//        FileOutputStream out = new FileOutputStream("/Users/ptn/Downloads/olatrading.xls")
//        Workbook workbook = new SalesReportService().buildReport(sales)
//        workbook.write(out)
//        out.close()
//    }
}
