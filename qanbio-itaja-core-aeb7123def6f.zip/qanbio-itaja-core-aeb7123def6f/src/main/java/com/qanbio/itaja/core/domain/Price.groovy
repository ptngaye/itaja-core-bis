package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder

import javax.persistence.*
import java.time.Instant

//Un prix concerne un poduit, pour une quantité minimale et prend effet à partir d'une date donnée
@Entity
@Table(name = "prices")
@JsonPropertyOrder(alphabetic = true)
class Price {
    @JsonProperty("id")
    @Column(name = "price_id")
    @Id
    Long id

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    Product product

    @JsonProperty("quantityMin")
    @Column(name = "quantity_min")
    int quantityMin //Quantité minimum pour que ce prix soit appliqué, (default = 1)

    @JsonProperty("amount")
    @Column(name = "amount")
    BigDecimal amount

    @JsonProperty("createdAt")
    @Column(name = "created_at")
    Instant createdAt

    @JsonProperty("startDate")
    @Column(name = "start_date")
    Instant startDate
}