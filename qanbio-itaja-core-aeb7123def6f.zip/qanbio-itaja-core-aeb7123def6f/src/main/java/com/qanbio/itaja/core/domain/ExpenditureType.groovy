package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*

@Entity
@Table(name = "expenditure_types")
@JsonPropertyOrder(alphabetic = true)
class ExpenditureType {
    @JsonProperty("id")
    @Column(name = "expenditure_type_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @NotBlank(message = "{ExpenditureType.shortName.NotBlank}")
    @JsonProperty("shortName")
    @Column(name = "short_name")
    String shortName

    @NotBlank(message = "{ExpenditureType.name.NotBlank}")
    @JsonProperty("name")
    @Column(name = "name")
    String name

    @JsonProperty("syscohadaId")
    @Column(name = "syscohada_id")
    Integer syscohadaId

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "company_id")
    @JsonBackReference
    Company company


}
//ENERGY,
//WATER,
//SALARY,
//RENT,
//SOFWARE,
//EQUIPEMENT,
//TELECOMMS,
//DEBT_REPAYMENT,
//PROCUREMENT


