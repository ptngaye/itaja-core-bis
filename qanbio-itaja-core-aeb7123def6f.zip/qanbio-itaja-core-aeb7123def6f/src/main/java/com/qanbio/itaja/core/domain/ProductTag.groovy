package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*
import javax.validation.constraints.NotNull

@Entity
@Table(name = "product_tags")
@JsonPropertyOrder(alphabetic = true)
class ProductTag {
    @JsonProperty("id")
    @Column(name = "product_tag_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @NotBlank(message = "{ProductTag.value.NotBlank}")
    @JsonProperty("value")
    @Column(name = "value")
    String value

    @JsonProperty("order")
    @Column(name = "order")
    Integer order

    @NotNull(message = "{ProductTag.company.NotBlank}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "company_id")
    @JsonBackReference
    Company company
}