package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.apache.commons.lang3.StringUtils
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*
import javax.validation.constraints.NotNull

@Entity
@Table(name = "products")
@JsonPropertyOrder(alphabetic = true)
class Product {
    @JsonProperty("id")
    @Column(name = "product_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @NotBlank(message = "{Product.reference.NotBlank}")
    @JsonProperty("reference")
    @Column(name = "reference")
    String reference

    @NotBlank(message = "{Product.name.NotBlank}")
    @JsonProperty("name")
    @Column(name = "name")
    String name

    @NotBlank(message = "{Product.unit.NotBlank}")
    @JsonProperty("unit")
    @Column(name = "unit")
    String unit

    @Transient
    @JsonProperty("labels")
    List<String> labels

    @NotNull(message = "{Product.company.NotBlank}")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id")
    @JsonBackReference
    Company company

    @JsonIgnore
    @Column(name = "flat_tag")
    String flatTag

    List<String> getLabels() {
        if (StringUtils.isBlank(flatTag)) {
            return new ArrayList<>()
        }
        flatTag.split("\\*\\*\\*").findAll { !StringUtils.isBlank(it) }
    }
}


