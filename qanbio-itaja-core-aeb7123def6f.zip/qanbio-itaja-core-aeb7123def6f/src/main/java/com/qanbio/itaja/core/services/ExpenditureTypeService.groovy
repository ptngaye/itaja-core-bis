package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.ExpenditureType
import com.qanbio.itaja.core.repositories.ExpenditureTypeRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ExpenditureTypeService {
    ExpenditureTypeRepository expenditureTypeRepository

    List<ExpenditureType> findAll() {
        expenditureTypeRepository.findAll()
    }

    List<ExpenditureType> findByCompanyId(Long companyId) {
        expenditureTypeRepository.findByCompany_Id(companyId)
    }

    ExpenditureType findOneById(Long productId) {
        expenditureTypeRepository.findOne(productId)
    }

    @Autowired
    void setExpenditureTypeRepository(ExpenditureTypeRepository expenditureTypeRepository) {
        this.expenditureTypeRepository = expenditureTypeRepository
    }
}
