package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Company
import com.qanbio.itaja.core.repositories.CompanyRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class CompanyService {
    CompanyRepository companyRepository

    List<Company> findAll() {
        companyRepository.findAll()
    }

    Company findOneById(Long companyId) {
        companyRepository.findOne(companyId)
    }

    @Autowired
    void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository
    }
}
