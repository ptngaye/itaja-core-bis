package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Product
import org.springframework.data.jpa.repository.JpaRepository

interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCompany_Id(Long companyId)
    //List<Product> findByReferenceAndCompany_Id(String reference, Long companyId)

}
