package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.hibernate.validator.constraints.Email
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*
import javax.validation.constraints.NotNull

@Entity(name = "employees")
@JsonPropertyOrder(alphabetic = true)
class Employee {
    @JsonProperty("id")
    @Column(name = "employee_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @NotBlank(message = "{Employee.lastName.NotBlank}")
    @JsonProperty("lastName")
    @Column(name = "last_name")
    String lastName

    @NotBlank(message = "{Employee.firstName.NotBlank}")
    @JsonProperty("firstName")
    @Column(name = "first_name")
    String firstName

    @Email(message = "{Employee.emailAdress.Email}")
    @JsonProperty("emailAddress")
    @Column(name = "email_address")
    String emailAddress

    @NotBlank(message = "{Employee.phoneNumber.NotBlank}")
    @JsonProperty("phoneNumber")
    @Column(name = "phone_number")
    String phoneNumber

    @NotNull(message = "{Employee.role.NotBlank}")
    @JsonProperty("role")
    @Column(name = "role")
    @Enumerated(EnumType.STRING)
    Role role

    @NotNull(message = "{Shop.company.NotBlank}")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id")
    @JsonBackReference
    Company company
}