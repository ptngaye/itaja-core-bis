package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder

import javax.persistence.*
import javax.validation.constraints.NotNull
import java.time.Instant

@Entity
@Table(name = "sales")
@JsonPropertyOrder(alphabetic = true)
class Sale {
    @JsonProperty("id")
    @Column(name = "sale_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @JsonProperty("createdAt")
    @Column(name = "created_at")
    Instant createdAt

    @JsonProperty("operationDate")
    @Column(name = "operation_date")
    Instant operationDate

    @JsonProperty("unitAmount")
    @Column(name = "unit_amount")
    BigDecimal unitAmount

    @JsonProperty("totalAmount")
    @Column(name = "total_amount")
    BigDecimal totalAmount

    @JsonProperty("quantity")
    @Column(name = "quantity")
    BigDecimal quantity

    @JsonProperty("note")
    @Column(name = "note")
    String note

    @NotNull(message = "{Sale.product.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    Product product

    @NotNull(message = "{Sale.shop.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "shop_id")
    Shop shop

    @NotNull(message = "{Sale.employee.NotNull}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_id")
    Employee employee
}
