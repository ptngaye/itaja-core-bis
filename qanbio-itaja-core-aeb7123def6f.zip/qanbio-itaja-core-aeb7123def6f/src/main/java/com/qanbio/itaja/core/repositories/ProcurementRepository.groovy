package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Procurement
import org.springframework.data.jpa.repository.JpaRepository

interface ProcurementRepository extends JpaRepository<Procurement, Long> {
    List<Procurement> findByShop_Id(Long shopId)
}
