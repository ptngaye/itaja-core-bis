package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Product
import com.qanbio.itaja.core.repositories.ProductRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ProductService {
    ProductRepository productRepository

    List<Product> findAll() {
        productRepository.findAll()
    }

    List<Product> findByCompanyId(Long companyId) {
        productRepository.findByCompany_Id(companyId)
    }

    Product findOneById(Long productId) {
        productRepository.findOne(productId)
    }

    @Autowired
    void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository
    }
}
