package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Price
import com.qanbio.itaja.core.repositories.PriceRepository
import groovy.transform.CompileStatic
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@CompileStatic
@Service
class PriceService {
    List<Price> findAll() {
        priceRepository.findAll()
    }

    List<Price> findByCompanyId(Long companyId) {
        priceRepository.findAll()
    }

    List<Price> findByProductId(Long productId) {
        priceRepository.findByProduct_Id(productId)
    }

    Price findOneById(Long saleId) {
        priceRepository.findOne(saleId)
    }

    PriceRepository priceRepository

    @Autowired
    void setPriceRepository(PriceRepository priceRepository) {
        this.priceRepository = priceRepository
    }
}