package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Sale
import org.springframework.data.jpa.repository.JpaRepository

interface SaleRepository extends JpaRepository<Sale, Long> {
    List<Sale> findByShop_Id(Long shopId)
}
