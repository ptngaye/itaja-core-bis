package com.qanbio.itaja.core.repositories

import javax.persistence.AttributeConverter
import javax.persistence.Converter
import java.sql.Timestamp
import java.time.Instant

@Converter(autoApply = true)
class InstantJpaConverter implements AttributeConverter<Instant, Timestamp> {

    @Override
    Timestamp convertToDatabaseColumn(Instant instant) {
        java.sql.Timestamp.from(instant)
    }

    @Override
    Instant convertToEntityAttribute(Timestamp dbData) {
        dbData.toInstant()
    }
}
