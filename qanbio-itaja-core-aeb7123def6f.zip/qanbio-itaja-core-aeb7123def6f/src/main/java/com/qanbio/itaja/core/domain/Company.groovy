package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonManagedReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import org.hibernate.validator.constraints.NotBlank

import javax.persistence.*

@Entity
@Table(name = "companies")
@JsonPropertyOrder(alphabetic = true)
class Company {
    @JsonProperty("id")
    @Column(name = "company_id")
    @Id
    Long id

    @NotBlank(message = "{Company.name.NotBlank}")
    @JsonProperty("name")
    @Column(name = "name")
    String name

    @JsonProperty("products")
    @OneToMany(mappedBy = "company", fetch = FetchType.EAGER)
    @JsonManagedReference
    Set<Product> products

    @JsonProperty("employees")
    @OneToMany(mappedBy = "company", fetch = FetchType.EAGER)
    @JsonManagedReference
    Set<Employee> employees

    @JsonProperty("shops")
    @OneToMany(mappedBy = "company", fetch = FetchType.EAGER)
    @JsonManagedReference
    Set<Shop> shops
}
