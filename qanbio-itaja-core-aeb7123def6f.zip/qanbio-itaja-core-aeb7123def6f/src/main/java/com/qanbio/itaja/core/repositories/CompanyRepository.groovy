package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Company
import org.springframework.data.jpa.repository.JpaRepository

interface CompanyRepository extends JpaRepository<Company, Long> {
}
