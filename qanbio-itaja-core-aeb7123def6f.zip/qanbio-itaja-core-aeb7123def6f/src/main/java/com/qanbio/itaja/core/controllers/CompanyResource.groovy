package com.qanbio.itaja.core.controllers

import com.qanbio.itaja.core.domain.*
import com.qanbio.itaja.core.services.*
import groovy.transform.CompileStatic
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import io.swagger.annotations.ApiParam
import org.apache.poi.ss.usermodel.Workbook
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.MediaType
import org.springframework.web.bind.annotation.*

import javax.servlet.http.HttpServletResponse

@Api(tags = "Resource 'Entreprise'")
@RestController
@RequestMapping(
        value = '/companies/{companyId}'
//        ,
//        produces = [MediaType.APPLICATION_JSON_UTF8_VALUE, 'application/vnd.ms-excel'],
//        consumes = [MediaType.APPLICATION_JSON_UTF8_VALUE]
)
class CompanyResource {
    @ApiOperation(value = "Lister tous les produits d'une entreprise")
    @GetMapping("/products")
    List<Product> findProductByCompany(@PathVariable Long companyId) {
        productService.findByCompanyId(companyId)
    }

    @ApiOperation(value = "Lister tous les prix d'une entreprise")
    @GetMapping("/prices")
    List<Price> findPriceByCompany(@PathVariable Long companyId) {
        priceService.findByCompanyId(companyId)
    }

    @ApiOperation(value = "Lister tous les types de dépense d'une entreprise")
    @GetMapping("/expenditure-types")
    List<ExpenditureType> findExpenditureTypeByCompany(@PathVariable Long companyId) {
        expenditureTypeService.findByCompanyId(companyId)
    }

    @ApiOperation(value = "Lister toutes les dépenses d'une entreprise")
    @GetMapping("/expenditures")
    List<Expenditure> findExpenditure(@PathVariable Long companyId) {
        expenditureService.findByCompanyId(companyId)
    }

    @ApiOperation(value = "Lister tous les types de dépense d'un magasin")
    @GetMapping("/{shopReference}/expenditures")
    List<Expenditure> findExpenditureByShop(@PathVariable Long companyId,
                                                @PathVariable String shopReference) {
        expenditureService.findByShopReferenceAndByCompanyId(companyId, shopReference)
    }

    @ApiOperation(value = "Lister tous les points de vente d'une entreprise")
    @GetMapping("/shops")
    List<Shop> findShopByCompany(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId) {
        shopService.findByCompanyId(companyId)
    }

    @ApiOperation(value = "Lister toutes les ventes d'un point de vente d'une entreprise")
    @GetMapping("/shops/{shopReference}/sales")
    def findSaleByShopReferenceAndByCompanyId(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference,
            @RequestParam(value = "product", required = false) String productReference,
            @RequestHeader("Content-Type") String contentType,
            HttpServletResponse httpServletResponse) {
        List<Sale> sales = saleService.findByShopReferenceAndByCompanyId(companyId, shopReference)

        if (productReference != null && !productReference.trim().isEmpty()) {
            sales = sales.findAll { it.product.reference == productReference }
        }

        if ('application/vnd.ms-excel' == contentType) {
            Workbook workbook = saleXlsReportService.buildReport(sales)
            httpServletResponse.setHeader('Content-disposition', 'attachment; filename=itaja.xls')
            workbook.write(httpServletResponse.getOutputStream())
        } else {
            sales
        }
    }

    @ApiOperation(value = "Enregistrer les ventes d'un point de vente d'une entreprise")
    @PatchMapping("/shops/{shopReference}/sales")
    List<Sale> createOrUpdateSale(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference,
            @ApiParam(name = "Ventes", value = "Lignes à créer ou à modifier", required = true)
            @RequestBody List<Sale> sales) {
        saleService.createOrUpdate(companyId, shopReference, sales)
    }

    @ApiOperation(value = "Lister tous les approvisionnement d'un point de vente d'une entreprise")
    @GetMapping("/shops/{shopReference}/procurements")
    List<Procurement> findProcurementByShopReferenceAndByCompanyId(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference) {
        procurementService.findByShopReferenceAndByCompanyId(companyId, shopReference)
    }

    @ApiOperation(value = "Enregistrer les approvisionnement d'un point de vente d'une entreprise")
    @PatchMapping("/shops/{shopReference}/procurements")
    List<Procurement> createOrUpdateProcurement(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference,
            @ApiParam(name = "Approvisionnements", value = "Lignes d'approvisionnement à créer ou à modiier", required = true)
            @RequestBody List<Procurement> procurements) {
        procurementService.createOrUpdate(companyId, shopReference, procurements)
    }

    @ApiOperation(value = "Lister tous les inventaires d'un point de vente d'une entreprise")
    @GetMapping("/shops/{shopReference}/inventories")
    List<Inventory> findInventoryByShopReferenceAndByCompanyId(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference) {
        inventoryService.findByShopReferenceAndByCompanyId(companyId, shopReference)
    }

    @ApiOperation(value = "Enregistrer les inventaires d'un point de vente d'une entreprise")
    @PatchMapping("/shops/{shopReference}/inventories")
    List<Inventory> createOrUpdateInventory(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference,
            @ApiParam(name = "Inventaires", value = "Lignes d'inventaires à créer ou à modiier", required = true)
            @RequestBody List<Inventory> inventories) {
        inventoryService.createOrUpdate(companyId, shopReference, inventories)
    }

    @ApiOperation(value = "Lister toutes les dépenses (hors appro) d'un point de vente d'une entreprise")
    @GetMapping("/shops/{shopReference}/expenditures")
    List<Expenditure> findExpenditureByShopReferenceAndByCompanyId(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference) {
        expenditureService.findByShopReferenceAndByCompanyId(companyId, shopReference)
    }

    @ApiOperation(value = "Enregistrer les dépenses (hors appro)  d'un point de vente d'une entreprise")
    @PatchMapping("/shops/{shopReference}/expenditures")
    List<Expenditure> createOrUpdateExpenditure(
            @ApiParam(name = "Identifiant de l'entreprise", value = "Identifiant numérique de l'entreprise, cet identifiant est celui fourni par l'équipe ITAJA ", required = true)
            @PathVariable Long companyId,
            @ApiParam(name = "Code du point de vente", value = "Code du point de vente, cet code est celui fourni par l'entreprise ", required = true)
            @PathVariable String shopReference,
            @ApiParam(name = "Inventaires", value = "Lignes d'inventaires à créer ou à modiier", required = true)
            @RequestBody List<Expenditure> expenditures) {
        expenditureService.createOrUpdate(companyId, shopReference, expenditures)
    }

    @GetMapping("/employees")
    List<Employee> findEmployeesByCompany(@PathVariable Long companyId) {
        employeeService.findByCompanyId(companyId)
    }

    CompanyService companyService
    ShopService shopService
    EmployeeService employeeService
    ProductService productService
    SaleService saleService
    ProcurementService procurementService
    InventoryService inventoryService
    ExpenditureService expenditureService
    ExpenditureTypeService expenditureTypeService
    SaleXlsReportService saleXlsReportService
    PriceService priceService

    @Autowired
    void setPriceService(PriceService priceService) {
        this.priceService = priceService
    }

    @Autowired
    void setSaleXlsReportService(SaleXlsReportService saleXlsReportService) {
        this.saleXlsReportService = saleXlsReportService
    }

    @Autowired
    void setCompanyService(CompanyService companyService) {
        this.companyService = companyService
    }

    @Autowired
    void setShopService(ShopService shopService) {
        this.shopService = shopService
    }

    @Autowired
    void setEmployeeService(EmployeeService employeeService) {
        this.employeeService = employeeService
    }

    @Autowired
    void setProductService(ProductService productService) {
        this.productService = productService
    }

    @Autowired
    void setSaleService(SaleService saleService) {
        this.saleService = saleService
    }

    @Autowired
    void setProcurementService(ProcurementService procurementService) {
        this.procurementService = procurementService
    }

    @Autowired
    void setInventoryService(InventoryService inventoryService) {
        this.inventoryService = inventoryService
    }

    @Autowired
    void setExpenditureService(ExpenditureService expenditureService) {
        this.expenditureService = expenditureService
    }

    @Autowired
    void setExpenditureTypeService(ExpenditureTypeService expenditureTypeService) {
        this.expenditureTypeService = expenditureTypeService
    }
}