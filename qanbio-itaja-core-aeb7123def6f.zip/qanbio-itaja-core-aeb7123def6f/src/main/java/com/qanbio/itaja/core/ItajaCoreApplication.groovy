package com.qanbio.itaja.core

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.context.annotation.Bean
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter

@SpringBootApplication
class ItajaCoreApplication {
    static void main(String[] args) {
        SpringApplication.run(ItajaCoreApplication.class, args)
    }

    @Bean
    WebMvcConfigurer corsConfigurer() {
        return new  WebMvcConfigurerAdapter() {
            @Override
            void addCorsMappings(CorsRegistry registry) {
                registry.addMapping('/**')
                        .allowedOrigins('http://localhost:9010', 'http://104.155.151.29:9010')
            }
        }
    }
}
