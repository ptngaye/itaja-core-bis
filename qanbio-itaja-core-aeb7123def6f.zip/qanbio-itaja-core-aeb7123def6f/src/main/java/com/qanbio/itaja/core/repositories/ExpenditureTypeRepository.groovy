package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.ExpenditureType
import org.springframework.data.jpa.repository.JpaRepository

interface ExpenditureTypeRepository extends JpaRepository<ExpenditureType, Long> {
    List<ExpenditureType> findByCompany_Id(Long companyId)

}
