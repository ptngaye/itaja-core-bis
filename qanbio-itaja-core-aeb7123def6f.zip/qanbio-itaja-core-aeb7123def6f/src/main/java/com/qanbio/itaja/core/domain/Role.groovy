package com.qanbio.itaja.core.domain

enum Role {
    OPERATIONAL,
    MANAGER
}
