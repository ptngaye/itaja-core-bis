package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Expenditure
import org.springframework.data.jpa.repository.JpaRepository

interface ExpenditureRepository extends JpaRepository<Expenditure, Long> {
    List<Expenditure> findByShop_Id(Long shopId)
}



