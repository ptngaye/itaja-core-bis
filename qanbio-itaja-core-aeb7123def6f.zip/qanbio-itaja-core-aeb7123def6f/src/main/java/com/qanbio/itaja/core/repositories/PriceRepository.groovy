package com.qanbio.itaja.core.repositories

import com.qanbio.itaja.core.domain.Price
import org.springframework.data.jpa.repository.JpaRepository

interface PriceRepository extends JpaRepository<Price, Long> {
    List<Price> findByProduct_Id(Long productId)
}
