package com.qanbio.itaja.core.repositories

import org.javamoney.moneta.Money

import javax.money.MonetaryAmount
import javax.persistence.AttributeConverter
import javax.persistence.Converter

@Converter(autoApply = true)
class MonetaryAmountJpaConverter implements AttributeConverter<MonetaryAmount, BigDecimal> {
    @Override
    BigDecimal convertToDatabaseColumn(MonetaryAmount money) {
        money.getNumber().numberValue(BigDecimal.class)
    }

    @Override
    MonetaryAmount convertToEntityAttribute(BigDecimal amount) {
        if (!amount) {
            return null
        }
        Money.of(amount, 'XOF')
    }
}
