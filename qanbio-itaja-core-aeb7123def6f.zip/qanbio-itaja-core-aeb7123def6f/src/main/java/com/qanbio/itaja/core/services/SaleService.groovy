package com.qanbio.itaja.core.services

import com.qanbio.itaja.core.domain.Employee
import com.qanbio.itaja.core.domain.Product
import com.qanbio.itaja.core.domain.Sale
import com.qanbio.itaja.core.domain.Shop
import com.qanbio.itaja.core.repositories.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import java.time.Instant

@Service
class SaleService {
    SaleRepository saleRepository
    CompanyRepository companyRepository
    ShopRepository shopRepository
    ProductRepository productRepository
    EmployeeRepository employeeRepository

    List<Sale> findAll() {
        saleRepository.findAll()
    }

    List<Sale> findByShopId(Long shopId) {
        saleRepository.findByShop_Id(shopId)
    }

    List<Sale> findByShopReferenceAndByCompanyId(Long companyId, String shopReference) {
        List<Shop> shops = shopRepository.findByCompany_Id(companyId)
        Shop shop = shops.find { Shop shop -> shop.reference == shopReference }
        saleRepository.findByShop_Id(shop.id)
    }

    Sale findOneById(Long saleId) {
        saleRepository.findOne(saleId)
    }

    List<Sale> createOrUpdate(Long companyId, String shopReference, List<Sale> sales) {
        Shop shop = companyRepository.findOne(companyId).shops.find { Shop shop -> shop.reference == shopReference }
        List<Product> products = productRepository.findByCompany_Id(companyId)
        List<Employee> employees = employeeRepository.findByCompany_Id(companyId)
        Instant now = Instant.now()

        sales.each { Sale sale ->
            sale.createdAt = now
            sale.shop = shop
            sale.product = products.find { it.reference == sale.product.reference }
            sale.employee = employees.find { it.phoneNumber == sale.employee.phoneNumber }
        }

        saleRepository.save(sales)
    }

    @Autowired
    void setSaleRepository(SaleRepository saleRepository) {
        this.saleRepository = saleRepository
    }

    @Autowired
    void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository
    }

    @Autowired
    void setShopRepository(ShopRepository shopRepository) {
        this.shopRepository = shopRepository
    }

    @Autowired
    void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository
    }

    @Autowired
    void setEmployeeRepository(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository
    }
}