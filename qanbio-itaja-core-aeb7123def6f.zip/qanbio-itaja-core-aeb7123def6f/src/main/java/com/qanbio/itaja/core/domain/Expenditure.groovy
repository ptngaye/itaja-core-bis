package com.qanbio.itaja.core.domain

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder

import javax.persistence.*
import javax.validation.constraints.NotNull
import java.time.Instant

@Entity
@Table(name = "expenditures")
@JsonPropertyOrder(alphabetic = true)
class Expenditure {
    @JsonProperty("id")
    @Column(name = "expenditure_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id

    @JsonProperty("createdAt")
    @Column(name = "created_at")
    Instant createdAt

    @JsonProperty("operationDate")
    @Column(name = "operation_date")
    Instant operationDate

    @JsonProperty("note")
    @Column(name = "note")
    String note

    @JsonProperty("amount")
    @Column(name = "amount")
    BigDecimal amount

    @NotNull(message = "{Expenditure.type.NotBlank}")
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "expenditure_type_id")
    @JsonBackReference
    ExpenditureType type

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "shop_id")
    Shop shop
}

